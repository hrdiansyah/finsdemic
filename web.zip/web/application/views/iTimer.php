<div class="lv_timer_wrapper lv_single_index_menu">
	<div class="overlay">
			<div class="container-fluid">	
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="lv_timer_info">
							<h1>Jakarta Event Now</h1>
							<p>11 August 2020, Indonesia</p>
						</div>
						
						<div id="clockdiv">
							<div><span class="days"></span><div class="smalltext"><b>Days</b></div></div>
							<div><span class="hours"></span><div class="smalltext"><b>Hours</b></div></div>
							<div><span class="minutes"></span><div class="smalltext"><b>Minutes</b></div></div>
							<div><span class="seconds"></span><div class="smalltext"><b>Seconds</b></div></div>
						</div>
					</div>
				</div>
				<div class="scroll_down">
					<a href="#down" class="smoothScroll"><img src="<?=base_url()?>assets/edm/images/header/Wireless-Mouse.png" alt="icon"/><br>Scroll Down</a>
				</div>
			</div>
		</div>
	</div>
</div>	