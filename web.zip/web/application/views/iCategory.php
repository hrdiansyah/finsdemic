<div class="categories_sec_wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="category1_wrapper">
					<div class="category1">
						<img src="<?=base_url()?>assets/edm/images/header/category_pin.png" alt="icon_pin"/>
						<h3>Jakarta</h3>
						<p>Indonesia</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="category1_wrapper">
					<div class="category1">
						<img src="<?=base_url()?>assets/edm/images/header/category2_pin.png" alt="icon_pin"/>
						<h3>11 August</h3>
						<p>2020</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="category1_wrapper">
					<div class="category1">
						<img src="<?=base_url()?>assets/edm/images/header/category3_pin.png" alt="icon_pin"/>
						<h3>12 Speakers</h3>
						<p>EXPERTS</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="category1_wrapper">
					<div class="category1">
						<img src="<?=base_url()?>assets/edm/images/header/category4_pin.png" alt="icon_pin"/>
						<h3>100 Seats</h3>
						<p>CONFIRM</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>